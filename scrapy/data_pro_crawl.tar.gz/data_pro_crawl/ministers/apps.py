from django.apps import AppConfig


class MinistersConfig(AppConfig):
    name = 'ministers'
